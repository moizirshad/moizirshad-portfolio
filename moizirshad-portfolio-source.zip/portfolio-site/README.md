# Moiz Irshad — Mobile Engineering Lead

A responsive Flutter Web portfolio for a mobile engineering lead with 12+ years across native iOS, Android, Flutter and product delivery. The site includes project filtering, individual case-study routes, a dark/light theme toggle, verified experience, architecture overview, skills, contact links and a CV download.

## Run locally

Install Flutter stable, then:

```sh
flutter pub get
flutter run -d chrome
```

## Verify and build

```sh
flutter analyze
flutter test
flutter build web --release --base-href /moizirshad/
```

The GitHub Actions workflow runs analysis, tests and the release build, then deploys `build/web` to GitHub Pages. The verified repository name is `moizirshad`, so the project-site base path is `/moizirshad/`. Enable Pages in repository settings with **GitHub Actions** as the build and deployment source. The workflow deploys on pushes to `main` and can be run manually.

Flutter Web uses client-side rendering. The site includes page metadata, Open Graph preview art, a favicon, robots.txt and a sitemap, but search engines may not index every dynamically rendered case study. Keep the home page descriptive and add pre-rendered HTML if search visibility for individual case studies becomes important. Routes use Flutter's default hash routing, which can be refreshed on static hosting.

For a custom domain, configure the domain in GitHub Pages, add its DNS records, and update the canonical URL, sitemap and Open Graph URL/image in `web/index.html` and `web/robots.txt`.

## Content and verified scope

Project content lives separately in `lib/data/projects.dart`; the experience and skills source is in `lib/main.dart`. Add projects to the shared `Project` model and provide evidence, role, platforms, technologies, outcomes and links before including them. Case-study pages use the same fields and deliberately leave unknown details out.

Included case studies:

- **FITT Meals:** Flutter apps built from scratch; the customer and meal figures are business-scale data, not app-specific usage metrics.
- **DubiCars:** native iOS/Android and Flutter work; 40% cross-platform feature development time improvement and individual performance/release outcomes from the CV. Download, rating and crash-free figures are product-wide.
- **Bykea:** sole iOS engineering for mobility and payment features; 2M+ daily active users is a platform figure.
- **Danat eVentures:** mobile team leadership and client delivery.
- **Argaam** and **Akhbaar24:** native iOS project records verified through the CV and public profile; deeper implementation details remain intentionally limited.

The project artwork is an original illustrative device composition, not a screenshot of shipped applications. No private source repository is linked as open source. React Native is marked as unverified for a production case study; no backend ownership is claimed beyond evidenced mobile API integration and collaboration.

## Information to confirm or add

- A named React Native project, if one should be represented as production experience.
- What was built for FITT Meals' NutriBot and the exact DubiCars Flutter migration approach.
- Current App Store / Google Play / product links and approved real screenshots or demos.
- Confirmation of the Danat end month, DubiCars work mode and FITT employment type (the site currently uses CV dates and its overlap note).
- Optional FITT product metrics and a concrete AI-assisted engineering example.
- If you want an exact custom domain, set it in GitHub Pages and update the SEO URLs.

## Deployment status

This directory contains deploy-ready configuration, but deployment has not been run. Push the project to the `moizirshad` GitHub repository and enable GitHub Actions Pages deployment to publish it.

import 'package:url_launcher/url_launcher.dart';

Future<void> downloadCv(String url, String filename) async {
  await launchUrl(Uri.parse(url), webOnlyWindowName: '_blank');
}
